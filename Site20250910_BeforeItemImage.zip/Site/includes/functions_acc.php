<?php
// File: /includes/function_acc.php
// All backend functions for the Accounts module.

defined('_IN_APP_') or die('Unauthorized access');

// -----------------------------------------
// ----- Chart of Accounts (CoA) Functions -----
// -----------------------------------------

/**
 * Searches and filters the Chart of Accounts.
 *
 * @param array $filters An associative array of filters.
 * @return array The list of accounts.
 */

function search_chart_of_accounts($filters = []) {
    $db = db();
    if (!$db) return [];

    $sql = "SELECT account_id, account_name, account_type, normal_balance, is_active FROM acc_chartofaccounts WHERE 1=1";
    
    $params = [];
    $types = '';

    if (!empty($filters['account_name'])) {
        $sql .= " AND account_name LIKE ?";
        $params[] = '%' . $filters['account_name'] . '%';
        $types .= 's';
    }

    if (!empty($filters['account_type'])) {
        $sql .= " AND account_type = ?";
        $params[] = $filters['account_type'];
        $types .= 's';
    }

    // --- NEW: Add logic for the status filter ---
    if (isset($filters['is_active']) && $filters['is_active'] !== '') {
        $sql .= " AND is_active = ?";
        $params[] = $filters['is_active'];
        $types .= 'i'; // 'i' for integer (0 or 1)
    }

    $sql .= " ORDER BY account_type, account_name";
    
    $stmt = $db->prepare($sql);
    if (!$stmt) {
        error_log("Chart of Accounts Search Prepare Failed: " . $db->error);
        return [];
    }
    
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
}
// ----------------End----------------------

/**
 * Retrieves a single account by its ID.
 *
 * @param int $account_id The ID of the account to fetch.
 * @return array|null The account data or null if not found.
 */
function get_account($account_id) {
    $db = db();
    if (!$db) return null;

    $stmt = $db->prepare("SELECT * FROM acc_chartofaccounts WHERE account_id = ?");
    if (!$stmt) return null;

    $stmt->bind_param("i", $account_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result ? $result->fetch_assoc() : null;
}
// ----------------End----------------------

/**
 * Adds a new account to the Chart of Accounts.
 *
 * @param array $details An associative array of account details.
 * @return int The ID of the newly inserted account.
 * @throws Exception On failure.
 */
function add_account($details) {
    $db = db();
    if (!$db) throw new Exception("Database connection failed.");

    // Basic validation
    if (empty($details['account_name']) || empty($details['account_type']) || empty($details['normal_balance'])) {
        throw new Exception("Account Name, Type, and Normal Balance are required.");
    }

    $sql = "INSERT INTO acc_chartofaccounts (account_name, account_type, normal_balance, description, is_active) VALUES (?, ?, ?, ?, ?)";
    $stmt = $db->prepare($sql);
    if (!$stmt) throw new Exception("Database prepare failed: " . $db->error);

    $stmt->bind_param(
        "ssssi",
        $details['account_name'],
        $details['account_type'],
        $details['normal_balance'],
        $details['description'],
        $details['is_active']
    );

    if (!$stmt->execute()) {
        // Check for duplicate name error
        if ($db->errno === 1062) {
            throw new Exception("An account with this name already exists.");
        }
        throw new Exception("Failed to create new account: " . $stmt->error);
    }

    return $db->insert_id;
}
// ----------------End----------------------

/**
 * Updates an existing account in the Chart of Accounts.
 *
 * @param int $account_id The ID of the account to update.
 * @param array $details An associative array of account details.
 * @return bool True on success.
 * @throws Exception On failure.
 */
function update_account($account_id, $details) {
    $db = db();
    if (!$db) throw new Exception("Database connection failed.");

    // Basic validation
    if (empty($account_id) || empty($details['account_name']) || empty($details['account_type']) || empty($details['normal_balance'])) {
        throw new Exception("Account Name, Type, and Normal Balance are required.");
    }

    $sql = "UPDATE acc_chartofaccounts SET account_name = ?, account_type = ?, normal_balance = ?, description = ?, is_active = ? WHERE account_id = ?";
    $stmt = $db->prepare($sql);
    if (!$stmt) throw new Exception("Database prepare failed: " . $db->error);

    $stmt->bind_param(
        "ssssii",
        $details['account_name'],
        $details['account_type'],
        $details['normal_balance'],
        $details['description'],
        $details['is_active'],
        $account_id
    );

    if (!$stmt->execute()) {
        // Check for duplicate name error
        if ($db->errno === 1062) {
            throw new Exception("An account with this name already exists.");
        }
        throw new Exception("Failed to update account: " . $stmt->error);
    }

    return true;
}
// ------------------------------------End------------------------------------------

/**
 * Retrieves a simple list of all active accounts for use in dropdown menus.
 *
 * @return array A list of accounts, each with 'account_id' and 'account_name'.
 */
function get_all_active_accounts() {
    $db = db();
    if (!$db) return [];

    $sql = "SELECT account_id, account_name FROM acc_chartofaccounts WHERE is_active = 1 ORDER BY account_name ASC";
    $result = $db->query($sql);
    
    return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
}
// ------------------------------------End------------------------------------------

// -----------------------------------------
// ----- Journal Entry Functions -----
// -----------------------------------------

/**
 * Processes a double-entry journal transaction (can be manual or automated).
 * Now includes the 'remarks' field.
 *
 * @param array $details An associative array with transaction details.
 * @param string $source_type The type of record that generated this transaction.
 * @param string|null $source_id The ID of the source record.
 * @param mysqli $db An existing database connection to use within a transaction.
 * @return string The transaction_group_id for the new entry.
 * @throws Exception On validation or database errors.
 */

function process_journal_entry($details, $source_type, $source_id, $db) {
    // --- Data Validation ---
    if (empty($details['transaction_date']) || empty($details['description']) || empty($details['debit_account_id']) || empty($details['credit_account_id']) || !isset($details['amount'])) {
        throw new Exception("Date, Description, Debit Account, Credit Account, and Amount are all required.");
    }
    if (!is_numeric($details['amount']) || $details['amount'] <= 0) {
        throw new Exception("Amount must be a positive number.");
    }
    if ($details['debit_account_id'] == $details['credit_account_id']) {
        throw new Exception("Debit and Credit accounts cannot be the same.");
    }

    // Generate a unique ID for this pair of transactions
    $transaction_group_id = generate_sequence_id('transaction_id', 'acc_transactions', 'transaction_group_id');
    
    // MODIFIED: Added the `remarks` column to the INSERT statement
    $sql = "INSERT INTO acc_transactions 
            (transaction_group_id, account_id, transaction_date, financial_year, description, remarks, debit_amount, credit_amount, source_type, source_id, created_by_name) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $db->prepare($sql);
    if (!$stmt) throw new Exception("Database prepare failed: " . $db->error);

    // --- Prepare Shared Data ---
    $user_name = $_SESSION['username'] ?? 'Unknown';
    $transaction_date = $details['transaction_date'] . ' ' . date('H:i:s');
    $amount = (float)$details['amount'];
    $description = trim($details['description']);
    $remarks = trim($details['remarks'] ?? ''); // Get remarks, default to empty string if not set

    // Determine financial year
    $year = date('Y', strtotime($details['transaction_date']));
    $month = date('m', strtotime($details['transaction_date']));
    $financial_year = ($month >= 4) ? $year . '-' . ($year + 1) : ($year - 1) . '-' . $year;

    // --- 1. The DEBIT Entry ---
    $debit_amount = $amount;
    $credit_amount = null;
    // MODIFIED: Added 's' for remarks and the $remarks variable to bind_param
    $stmt->bind_param("sissssddsss", $transaction_group_id, $details['debit_account_id'], $transaction_date, $financial_year, $description, $remarks, $debit_amount, $credit_amount, $source_type, $source_id, $user_name);
    $stmt->execute();
    
    // --- 2. The CREDIT Entry ---
    $debit_amount = null;
    $credit_amount = $amount;
    // MODIFIED: Added 's' for remarks and the $remarks variable to bind_param
    $stmt->bind_param("sissssddsss", $transaction_group_id, $details['credit_account_id'], $transaction_date, $financial_year, $description, $remarks, $debit_amount, $credit_amount, $source_type, $source_id, $user_name);
    $stmt->execute();
    
    return $transaction_group_id;
}

// -----------------------------------------
// ----- Automated Transaction Functions -----
// -----------------------------------------

/**
 * Creates the accounting entries for a paid sales order.
 * This function is idempotent: it checks for existing entries and only creates what is missing.
 *
 * @param string $order_id The ID of the sales order.
 * @param mysqli $db The existing database connection for transaction integrity.
 * @return bool True on success.
 * @throws Exception On failure.
 */
function record_sales_transaction($order_id, $db) {
    // Step 1: Fetch the main order details
    $stmt_order = $db->prepare("SELECT total_amount, other_expenses, payment_method, order_date FROM orders WHERE order_id = ?");
    if (!$stmt_order) throw new Exception("DB prepare failed for fetching order details.");
    $stmt_order->bind_param("s", $order_id);
    $stmt_order->execute();
    $order = $stmt_order->get_result()->fetch_assoc();

    if (!$order) {
        throw new Exception("Sales Order #$order_id not found for accounting entry.");
    }
    
    // --- Step 2: Record the Sales Revenue Transaction (IF IT DOESN'T EXIST) ---
    $stmt_check_rev = $db->prepare("SELECT transaction_id FROM acc_transactions WHERE source_type = 'sales_order' AND source_id = ? AND description LIKE 'Sales revenue from Order #%'");
    $stmt_check_rev->bind_param("s", $order_id);
    $stmt_check_rev->execute();
    $revenue_exists = $stmt_check_rev->get_result()->num_rows > 0;
    
    if (!$revenue_exists) {
        $revenue_amount = (float)$order['total_amount'];
        if ($revenue_amount > 0) {
            $debit_account_name = ($order['payment_method'] === 'COD') ? 'Cash in Hand' : 'Bank Account';
            
            $stmt_acc = $db->prepare("SELECT account_id, account_name FROM acc_chartofaccounts WHERE account_name IN (?, 'Sales Revenue')");
            $stmt_acc->bind_param("s", $debit_account_name);
            $stmt_acc->execute();
            $accounts_res = $stmt_acc->get_result()->fetch_all(MYSQLI_ASSOC);
            $accounts = array_column($accounts_res, 'account_id', 'account_name');
            
            if (!isset($accounts[$debit_account_name]) || !isset($accounts['Sales Revenue'])) {
                throw new Exception("Could not find necessary system accounts ('$debit_account_name', 'Sales Revenue') in the Chart of Accounts.");
            }

            $revenue_details = [
                'transaction_date'  => $order['order_date'],
                'description'       => 'Sales revenue from Order #' . $order_id,
                'remarks'           => '', // Remarks can be added if needed in the future
                'debit_account_id'  => $accounts[$debit_account_name],
                'credit_account_id' => $accounts['Sales Revenue'],
                'amount'            => $revenue_amount,
            ];
            process_journal_entry($revenue_details, 'sales_order', $order_id, $db);
        }
    }

    // --- Step 3: Record the Cost of Goods Sold (COGS) Transaction (IF IT DOESN'T EXIST) ---
    $stmt_check_cogs = $db->prepare("SELECT transaction_id FROM acc_transactions WHERE source_type = 'sales_order' AND source_id = ? AND description LIKE 'Cost of goods sold for Order #%'");
    $stmt_check_cogs->bind_param("s", $order_id);
    $stmt_check_cogs->execute();
    $cogs_exists = $stmt_check_cogs->get_result()->num_rows > 0;

    if (!$cogs_exists) {
        $stmt_items = $db->prepare("SELECT SUM(quantity * cost_price) as total_cogs FROM order_items WHERE order_id = ?");
        if (!$stmt_items) throw new Exception("DB prepare failed for fetching order items for COGS.");
        $stmt_items->bind_param("s", $order_id);
        $stmt_items->execute();
        $cogs_data = $stmt_items->get_result()->fetch_assoc();
        
        $cogs_amount = (float)($cogs_data['total_cogs'] ?? 0);
        if ($cogs_amount > 0) {
            $stmt_acc_cogs = $db->prepare("SELECT account_id, account_name FROM acc_chartofaccounts WHERE account_name IN ('Cost of Goods Sold', 'Inventory')");
            $stmt_acc_cogs->execute();
            $accounts_cogs_res = $stmt_acc_cogs->get_result()->fetch_all(MYSQLI_ASSOC);
            $cogs_accounts = array_column($accounts_cogs_res, 'account_id', 'account_name');

            if (!isset($cogs_accounts['Cost of Goods Sold']) || !isset($cogs_accounts['Inventory'])) {
                throw new Exception("Could not find necessary system accounts ('Cost of Goods Sold', 'Inventory') in the Chart of Accounts.");
            }

            $cogs_details = [
                'transaction_date'  => $order['order_date'],
                'description'       => 'Cost of goods sold for Order #' . $order_id,
                'remarks'           => '', // Remarks can be added if needed in the future
                'debit_account_id'  => $cogs_accounts['Cost of Goods Sold'],
                'credit_account_id' => $cogs_accounts['Inventory'],
                'amount'            => $cogs_amount,
            ];
            process_journal_entry($cogs_details, 'sales_order', $order_id, $db);
        }
    }
    
    return true;
}
// ----------------End----------------------

/**
 * Processes the receipt of a PO, finalizes landed costs, and creates all logistics and inventory journal entries.
 *
 * @param string $po_id The ID of the Purchase Order.
 * @param float $total_logistic_cost The total logistic cost in local currency.
 * @param int $logistic_paid_by_account_id The ID of the account that paid for logistics.
 * @param mysqli $db The existing database connection.
 * @return void
 * @throws Exception On failure.
 */
function process_po_receipt_and_logistics($po_id, $total_logistic_cost, $logistic_paid_by_account_id, $db, $event_date = null) {
    // Step 1: Save the logistic details to the main PO record
    $stmt_update_po = $db->prepare("UPDATE purchase_orders SET total_logistic_cost = ?, logistic_paid_by_account_id = ? WHERE purchase_order_id = ?");
    if (!$stmt_update_po) throw new Exception("DB prepare failed for updating PO logistic details.");
    $stmt_update_po->bind_param("dis", $total_logistic_cost, $logistic_paid_by_account_id, $po_id);
    $stmt_update_po->execute();

    // Step 2: Fetch all items to get their weights and current cost_price
    $stmt_fetch_items = $db->prepare("SELECT po_item_id, cost_price, weight_grams, quantity FROM purchase_order_items WHERE purchase_order_id = ?");
    $stmt_fetch_items->bind_param("s", $po_id);
    $stmt_fetch_items->execute();
    $items = $stmt_fetch_items->get_result()->fetch_all(MYSQLI_ASSOC);
    
    $total_weight = array_sum(array_map(fn($item) => $item['weight_grams'] * $item['quantity'], $items));

    if ($total_weight > 0 && $total_logistic_cost > 0) {
        // Step 3: Calculate cost per gram and update each item's final landed cost
        $cost_per_gram = $total_logistic_cost / $total_weight;
        $stmt_update_item = $db->prepare("UPDATE purchase_order_items SET cost_price = ? WHERE po_item_id = ?");
        if (!$stmt_update_item) throw new Exception("DB prepare failed for updating final item costs.");

        foreach($items as $item) {
            $prorated_logistic_cost = ($item['weight_grams'] * $cost_per_gram);
            $final_landed_cost = $item['cost_price'] + $prorated_logistic_cost;
            $stmt_update_item->bind_param("di", $final_landed_cost, $item['po_item_id']);
            $stmt_update_item->execute();
        }
    }

    // --- Step 4: Create Accounting Journal Entry for Logistics ONLY ---
    $stmt_acc = $db->prepare("SELECT account_id FROM acc_chartofaccounts WHERE account_name = 'Inventory'");
    $stmt_acc->execute();
    $inventory_account_id = $stmt_acc->get_result()->fetch_assoc()['account_id'];
    if (!$inventory_account_id) {
        throw new Exception("Critical Error: 'Inventory' account not found.");
    }

    $transaction_date = $event_date ? date('Y-m-d', strtotime($event_date)) : date('Y-m-d');

    // Entry A: Record logistics cost if it exists.
    if ($total_logistic_cost > 0 && $logistic_paid_by_account_id) {
        $logistic_details = [
            'transaction_date'  => $transaction_date,
            'description'       => 'Payment for logistics (Ref PO #' . $po_id . ')',
            'remarks'           => '',
            'debit_account_id'  => $inventory_account_id, // Logistics cost adds to inventory value
            'credit_account_id' => $logistic_paid_by_account_id,
            'amount'            => $total_logistic_cost,
        ];
        process_journal_entry($logistic_details, 'purchase_order', $po_id, $db);
    }
    
    // Step 5: Create the GRN which adjusts the physical stock levels.
    $new_grn_id = auto_generate_grn_from_po($po_id, $db);

    // Step 6: Fulfill any linked sales orders
    $stmt_final_links = $db->prepare("SELECT sales_order_id FROM po_so_links WHERE purchase_order_id = ?");
    $stmt_final_links->bind_param("s", $po_id);
    $stmt_final_links->execute();
    $final_links_result = $stmt_final_links->get_result()->fetch_all(MYSQLI_ASSOC);
    $linked_order_ids = array_column($final_links_result, 'sales_order_id');

    if (!empty($linked_order_ids)) {
        foreach ($linked_order_ids as $linked_order_id) {
            fulfill_linked_sales_order($linked_order_id, $po_id, $db);
        }
    }

    return $new_grn_id; // Return the GRN ID for the feedback message
}
// ----------------End----------------------


// ----------------------------------End-----------------------------------------

/**
 * Retrieves a list of distinct financial years from the transactions table.
 *
 * @return array A list of financial year strings.
 */
function get_distinct_financial_years() {
    $db = db();
    if (!$db) return [];

    $sql = "SELECT DISTINCT financial_year FROM acc_transactions ORDER BY financial_year DESC";
    $result = $db->query($sql);
    
    return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
}
// ----------------------------------End-----------------------------------------

// -----------------------------------------
// ----- Transaction Reporting Functions -----
// -----------------------------------------

/**
 * Searches and filters the account transactions (General Ledger).
 * Now includes filtering by Financial Year.
 *
 * @param array $filters An associative array of filters.
 * @return array The list of transactions.
 */
function get_account_transactions($filters = []) {
    $db = db();
    if (!$db) return [];

    $sql = "
        SELECT 
            t.transaction_id,
            t.transaction_group_id,
            t.transaction_date,
            t.financial_year,
            t.description,
            t.remarks,
            t.debit_amount,
            t.credit_amount,
            t.status, -- THIS LINE WAS MISSING
            t.source_type,
            t.source_id,
            a.account_name,
            a.account_type
        FROM acc_transactions t
        JOIN acc_chartofaccounts a ON t.account_id = a.account_id
        WHERE 1=1
    ";

    $params = [];
    $types = '';

    // Filter by Date Range
    if (!empty($filters['date_from'])) {
        $sql .= " AND DATE(t.transaction_date) >= ?";
        $params[] = $filters['date_from'];
        $types .= 's';
    }
    if (!empty($filters['date_to'])) {
        $sql .= " AND DATE(t.transaction_date) <= ?";
        $params[] = $filters['date_to'];
        $types .= 's';
    }

    // Filter by a specific Account
    if (!empty($filters['account_id'])) {
        $sql .= " AND t.account_id = ?";
        $params[] = $filters['account_id'];
        $types .= 'i';
    }

    // Filter by Description text search
    if (!empty($filters['description'])) {
        $sql .= " AND t.description LIKE ?";
        $params[] = '%' . $filters['description'] . '%';
        $types .= 's';
    }
    
    // --- NEW: Filter by Financial Year ---
    if (!empty($filters['financial_year'])) {
        $sql .= " AND t.financial_year = ?";
        $params[] = $filters['financial_year'];
        $types .= 's';
    }
    // --- END NEW ---

    if (!empty($filters['status'])) {
        $sql .= " AND t.status = ?";
        $params[] = $filters['status'];
        $types .= 's';
    }
    // --- END NEW BLOCK ---

    $sql .= " ORDER BY t.transaction_date DESC, t.transaction_group_id DESC, t.credit_amount ASC";
    
    $stmt = $db->prepare($sql);
    if (!$stmt) {
        error_log("Account Transaction Search Prepare Failed: " . $db->error);
        return [];
    }
    
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
}
// ----------------------------------End-----------------------------------------

/**
 * Cancels a manual journal entry by creating a reversing entry.
 *
 * @param string $transaction_group_id The group ID of the transaction to cancel.
 * @return string The group ID of the new reversing transaction.
 * @throws Exception On failure.
 */
function cancel_manual_journal_entry($transaction_group_id) {
    $db = db();
    if (!$db) throw new Exception("Database connection failed.");

    $db->begin_transaction();
    try {
        // Step 1: Fetch the original debit and credit entries
        $stmt_fetch = $db->prepare("SELECT * FROM acc_transactions WHERE transaction_group_id = ? AND status = 'Posted'");
        $stmt_fetch->bind_param("s", $transaction_group_id);
        $stmt_fetch->execute();
        $original_txns = $stmt_fetch->get_result()->fetch_all(MYSQLI_ASSOC);

        if (count($original_txns) !== 2) {
            throw new Exception("Transaction not found or is already canceled/invalid.");
        }

        // Identify original debit and credit
        $original_debit = null;
        $original_credit = null;
        foreach($original_txns as $txn) {
            if ($txn['debit_amount'] !== null) $original_debit = $txn;
            if ($txn['credit_amount'] !== null) $original_credit = $txn;
        }

        if (!$original_debit || !$original_credit) {
            throw new Exception("Original transaction is malformed.");
        }

        // Step 2: Create a new reversing journal entry
        $reversal_details = [
            'transaction_date'  => date('Y-m-d'),
            'description'       => 'Reversal of transaction ' . $transaction_group_id,
            'remarks'           => 'Automated reversal of manual entry.',
            // The debit/credit accounts are now flipped
            'debit_account_id'  => $original_credit['account_id'],
            'credit_account_id' => $original_debit['account_id'],
            'amount'            => $original_debit['debit_amount'],
        ];
        
        $reversal_group_id = process_journal_entry($reversal_details, 'manual_entry', $transaction_group_id, $db);

        // Step 3: Mark BOTH the original and the new reversal transaction as 'Canceled'
        $stmt_update = $db->prepare("UPDATE acc_transactions SET status = 'Canceled' WHERE transaction_group_id IN (?, ?)");
        $stmt_update->bind_param("ss", $transaction_group_id, $reversal_group_id);
        $stmt_update->execute();
        
        $db->commit();
        
        return $reversal_group_id;

    } catch (Exception $e) {
        $db->rollback();
        throw new Exception("Failed to cancel journal entry: " . $e->getMessage());
    }
}
// ----------------------------------End-----------------------------------------

/**
 * Processes the supplier payment for a PO, updates item costs, and creates the journal entry.
 *
 * @param string $po_id The ID of the Purchase Order.
 * @param float $total_paid_lkr The total amount paid in local currency.
 * @param int $paid_by_account_id The ID of the account used for payment.
 * @param string|null $payment_date The actual date the payment was made.
 * @return bool True on success.
 * @throws Exception On failure.
 */
function process_po_payment_and_costs($po_id, $total_paid_lkr, $paid_by_account_id, $payment_date = null) {
    $db = db();
    if (!$db) throw new Exception("Database connection failed.");

    $db->begin_transaction();
    try {
        // Step 1: Save payment details to the main PO record (unchanged)
        $stmt_update_po = $db->prepare("UPDATE purchase_orders SET total_goods_cost = ?, goods_paid_by_account_id = ? WHERE purchase_order_id = ?");
        if (!$stmt_update_po) throw new Exception("DB prepare failed for updating PO payment details.");
        $stmt_update_po->bind_param("dis", $total_paid_lkr, $paid_by_account_id, $po_id);
        $stmt_update_po->execute();

        // Step 2: Calculate exchange rate and update item costs (unchanged)
        $stmt_fetch_items = $db->prepare("SELECT po_item_id, supplier_price, quantity FROM purchase_order_items WHERE purchase_order_id = ?");
        $stmt_fetch_items->bind_param("s", $po_id);
        $stmt_fetch_items->execute();
        $items = $stmt_fetch_items->get_result()->fetch_all(MYSQLI_ASSOC);
        $total_supplier_price_inr = array_sum(array_map(fn($item) => $item['supplier_price'] * $item['quantity'], $items));
        
        if ($total_supplier_price_inr > 0) {
            $exchange_rate = $total_paid_lkr / $total_supplier_price_inr;
            $stmt_update_item = $db->prepare("UPDATE purchase_order_items SET cost_price = ? WHERE po_item_id = ?");
            if (!$stmt_update_item) throw new Exception("DB prepare failed for updating item costs.");
            foreach($items as $item) {
                $item_landed_cost = ($item['supplier_price'] * $exchange_rate);
                $stmt_update_item->bind_param("di", $item_landed_cost, $item['po_item_id']);
                $stmt_update_item->execute();
            }
        }

        // --- DEFINITIVE FIX FOR THE JOURNAL ENTRY ---

        // Step 3: Dynamically look up the 'Inventory' account ID.
        $stmt_acc = $db->prepare("SELECT account_id FROM acc_chartofaccounts WHERE account_name = 'Inventory' LIMIT 1");
        $stmt_acc->execute();
        $inventory_account_id = $stmt_acc->get_result()->fetch_assoc()['account_id'] ?? null;
        
        if (!$inventory_account_id) {
            throw new Exception("Critical Error: 'Inventory' account not found in Chart of Accounts.");
        }

        // Step 4: Create the correct accounting journal entry using the correct date.
        $po_date_stmt = $db->prepare("SELECT po_date FROM purchase_orders WHERE purchase_order_id = ?");
        $po_date_stmt->bind_param("s", $po_id);
        $po_date_stmt->execute();
        $po_date = $po_date_stmt->get_result()->fetch_assoc()['po_date'];
        
        $payment_details = [
            // Use the payment_date from the modal. If it's not provided, fall back to the PO date.
            'transaction_date'  => $payment_date ? date('Y-m-d', strtotime($payment_date)) : $po_date,
            'description'       => 'Payment for goods (Ref PO #' . $po_id . ')',
            'remarks'           => '',
            'debit_account_id'  => $inventory_account_id, // CORRECT: Debit Inventory
            'credit_account_id' => $paid_by_account_id,
            'amount'            => $total_paid_lkr,
        ];
        process_journal_entry($payment_details, 'purchase_order', $po_id, $db);
        // --- END FIX ---
        
        $db->commit();
        return true;
    } catch (Exception $e) {
        $db->rollback();
        throw new Exception("Failed to process PO payment: " . $e->getMessage());
    }
}
// ----------------------------------End-----------------------------------------

/**
 * Calculates the trial balance for all active accounts as of a specific date.
 *
 * @param string $end_date The date (Y-m-d) to calculate the balance up to.
 * @return array An array containing the list of accounts with their balances, and the total debits and credits.
 */
function get_trial_balance($end_date) {
    $db = db();
    if (!$db) {
        throw new Exception("Database connection failed.");
    }

    // This single, powerful query calculates everything we need.
    $sql = "
        SELECT 
            ca.account_id,
            ca.account_name,
            ca.account_type,
            ca.normal_balance,
            COALESCE(SUM(t.debit_amount), 0) AS total_debits,
            COALESCE(SUM(t.credit_amount), 0) AS total_credits
        FROM 
            acc_chartofaccounts ca
        LEFT JOIN 
            acc_transactions t ON ca.account_id = t.account_id 
                               AND t.status = 'Posted' 
                               AND t.transaction_date <= ?
        WHERE 
            ca.is_active = 1
        GROUP BY 
            ca.account_id, ca.account_name, ca.account_type, ca.normal_balance
        ORDER BY 
            ca.account_type, ca.account_name
    ";

    $stmt = $db->prepare($sql);
    if (!$stmt) {
        throw new Exception("Database prepare failed: " . $db->error);
    }

    // Append the time to the end_date to include all transactions on that day.
    $end_date_with_time = $end_date . ' 23:59:59';
    $stmt->bind_param("s", $end_date_with_time);
    $stmt->execute();
    
    $result = $stmt->get_result();
    $accounts_data = $result->fetch_all(MYSQLI_ASSOC);

    $trial_balance = [];
    $total_debit_balance = 0;
    $total_credit_balance = 0;

    foreach ($accounts_data as $account) {
        $balance = 0;
        if ($account['normal_balance'] === 'debit') {
            $balance = $account['total_debits'] - $account['total_credits'];
            if ($balance > 0) {
                $total_debit_balance += $balance;
            } else {
                // If a debit account has a credit balance, it's unusual but possible.
                // We will still add it to the credit side for balancing purposes.
                $total_credit_balance += abs($balance);
            }
        } else { // normal_balance is 'credit'
            $balance = $account['total_credits'] - $account['total_debits'];
            if ($balance > 0) {
                $total_credit_balance += $balance;
            } else {
                // If a credit account has a debit balance.
                $total_debit_balance += abs($balance);
            }
        }

        // Only include accounts with activity or a non-zero balance
        if ($account['total_debits'] > 0 || $account['total_credits'] > 0) {
            $account['balance'] = $balance;
            $trial_balance[] = $account;
        }
    }

    return [
        'accounts' => $trial_balance,
        'total_debits' => $total_debit_balance,
        'total_credits' => $total_credit_balance
    ];
}
// ----------------------------------End-----------------------------------------

/**
 * Retrieves a detailed transaction ledger for a specific account within a date range.
 * It calculates an opening balance and a running balance for each transaction.
 *
 * @param int $account_id The ID of the account to fetch the ledger for.
 * @param string $start_date The start of the date range (Y-m-d).
 * @param string $end_date The end of the date range (Y-m-d).
 * @return array An array containing the opening balance, a list of transactions with running balances, and the closing balance.
 * @throws Exception On database or validation errors.
 */
function get_account_ledger($account_id, $start_date, $end_date) {
    $db = db();
    if (!$db) {
        throw new Exception("Database connection failed.");
    }
    if (empty($account_id) || empty($start_date) || empty($end_date)) {
        throw new Exception("Account ID, start date, and end date are required.");
    }

    // --- Step 1: Get the account's normal balance type ---
    $stmt_account = $db->prepare("SELECT normal_balance FROM acc_chartofaccounts WHERE account_id = ?");
    if (!$stmt_account) throw new Exception("DB prepare failed: " . $db->error);
    $stmt_account->bind_param("i", $account_id);
    $stmt_account->execute();
    $account_info = $stmt_account->get_result()->fetch_assoc();
    if (!$account_info) {
        throw new Exception("Account not found.");
    }
    $normal_balance_type = $account_info['normal_balance'];

    // --- Step 2: Calculate the Opening Balance (balance before the start_date) ---
    $stmt_opening = $db->prepare("
        SELECT 
            COALESCE(SUM(debit_amount), 0) as total_debits,
            COALESCE(SUM(credit_amount), 0) as total_credits
        FROM acc_transactions 
        WHERE account_id = ? 
          AND status = 'Posted' 
          AND transaction_date < ?
    ");
    if (!$stmt_opening) throw new Exception("DB prepare failed: " . $db->error);
    
    $start_date_for_query = $start_date . ' 00:00:00';
    $stmt_opening->bind_param("is", $account_id, $start_date_for_query);
    $stmt_opening->execute();
    $opening_totals = $stmt_opening->get_result()->fetch_assoc();
    
    $opening_balance = ($normal_balance_type === 'debit') 
        ? $opening_totals['total_debits'] - $opening_totals['total_credits'] 
        : $opening_totals['total_credits'] - $opening_totals['total_debits'];

    // --- Step 3: Fetch all transactions within the specified date range ---
    $stmt_transactions = $db->prepare("
        SELECT transaction_date, description, source_type, source_id, debit_amount, credit_amount
        FROM acc_transactions
        WHERE account_id = ?
          AND status = 'Posted'
          AND transaction_date BETWEEN ? AND ?
        ORDER BY transaction_date ASC, transaction_id ASC
    ");
    if (!$stmt_transactions) throw new Exception("DB prepare failed: " . $db->error);

    $end_date_for_query = $end_date . ' 23:59:59';
    $stmt_transactions->bind_param("iss", $account_id, $start_date_for_query, $end_date_for_query);
    $stmt_transactions->execute();
    $transactions = $stmt_transactions->get_result()->fetch_all(MYSQLI_ASSOC);

    // --- Step 4: Calculate the running balance for each transaction in PHP ---
    $running_balance = $opening_balance;
    foreach ($transactions as $key => $transaction) {
        if ($normal_balance_type === 'debit') {
            $running_balance += ($transaction['debit_amount'] ?? 0) - ($transaction['credit_amount'] ?? 0);
        } else { // credit
            $running_balance += ($transaction['credit_amount'] ?? 0) - ($transaction['debit_amount'] ?? 0);
        }
        $transactions[$key]['running_balance'] = $running_balance;
    }
    
    return [
        'opening_balance' => $opening_balance,
        'transactions' => $transactions,
        'closing_balance' => $running_balance // The final running balance is the closing balance
    ];
}
// ----------------------------------End-----------------------------------------

/**
 * Generates a URL to the source document page based on its type and ID.
 * This is a helper function to create clickable links in reports.
 *
 * @param string $source_type The type of the source document (e.g., 'sales_order', 'purchase_order').
 * @param string $source_id The unique ID of the source document.
 * @return string|null The URL to the document, or null if the type is not linkable.
 */
function get_source_document_url($source_type, $source_id) {
    if (empty($source_id) || empty($source_type)) {
        return null;
    }

    $url = null;

    switch ($source_type) {
        case 'sales_order':
            // Assuming your sales order view page is entry_order.php in the sales module
            $url = "/modules/sales/entry_order.php?order_id=" . urlencode($source_id);
            break;

        case 'purchase_order':
            // Assuming your purchase order view page is entry_purchase_order.php in the purchase module
            $url = "/modules/purchase/entry_purchase_order.php?purchase_order_id=" . urlencode($source_id);
            break;
        
        case 'grn':
             // Assuming your GRN view page is entry_grn.php in the purchase module
            $url = "/modules/purchase/entry_grn.php?grn_id=" . urlencode($source_id);
            break;

        // Add other cases here for future document types, e.g., 'expense_claim', 'invoice', etc.

        case 'manual_entry':
        default:
            // For manual entries or unknown types, we don't provide a link.
            $url = null;
            break;
    }

    return $url;
}
// ----------------------------------End-----------------------------------------


// ----------------------------------End-----------------------------------------
