<?php
require_once __DIR__.'/header.php';
require_once __DIR__.'/sidebar.php';
?>
<main class="main-content">
  <?php include $content; ?>
</main>
<?php require_once __DIR__.'/footer.php'; ?>
