<div class="sidebar">
  <ul>
    <li><a href="/index.php">🏠 Dashboard</a></li>
    <li><a href="/modules/item/entry.php">📦 Item Entry</a></li>
    <li><a href="#">📊 Reports</a></li>
  </ul>
</div>