<div class="card">
  <h3>Item Title</h3>
  <p>Description here...</p>
</div>