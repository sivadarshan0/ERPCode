<?php

// File: config/database.php

return [
    'host' => 'localhost',
    'username' => 'dbauser',
    'password' => 'dbauser',
    'database' => 'erpdb',
    'charset' => 'utf8mb4'
];