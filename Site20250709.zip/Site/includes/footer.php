<?php
// File: includes/footer.php
?>
    <footer class="dashboard-footer">
        <p>&copy; <?= date('Y') ?> ERP System. All rights reserved.</p>
    </footer>

    <script src="/assets/js/app.js"></script>
</body>
</html>
