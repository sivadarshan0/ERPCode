<?php
// File: modules/inventory/item.php

require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/../../includes/functions.php';
require_once __DIR__ . '/../../includes/header.php';

require_login();
$conn = db();

$msg = '';
$itemData = null;

// Fetch categories
$categories = $conn->query("SELECT CategoryCode, Category FROM category ORDER BY Category") ?: [];

// Fetch sub-categories grouped by category
$subCategoryMap = [];
$subCats = $conn->query("SELECT SubCategoryCode, SubCategory, CategoryCode FROM sub_category ORDER BY SubCategory") ?: [];
while($row = $subCats->fetch_assoc()) {
    $subCategoryMap[$row['CategoryCode']][] = $row;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $conn->begin_transaction();

        $item        = $_POST['item_name'] ?? '';
        $desc        = $_POST['description'] ?? '';
        $catCode     = $_POST['category_code'] ?? null;
        $subCatCode  = $_POST['sub_category_code'] ?? null;

        // Check if item exists
        $stmt = $conn->prepare("SELECT ItemCode FROM item WHERE Item = ?");
        $stmt->bind_param("s", $item);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // Update
            $stmt->bind_result($itemCode);
            $stmt->fetch();
            $stmt->close();

            $update = $conn->prepare("UPDATE item SET Description=?, CategoryCode=?, SubCategoryCode=? WHERE Item=?");
            $update->bind_param("ssss", $desc, $catCode, $subCatCode, $item);
            if ($update->execute()) {
                $msg = "✅ Item updated successfully (Code: <b>$itemCode</b>)";
            } else {
                $msg = "❌ Error updating: " . $conn->error;
            }
            $update->close();
        } else {
            // Insert
            $stmt->close();
            $insert = $conn->prepare("INSERT INTO item (Item, Description, CategoryCode, SubCategoryCode) VALUES (?, ?, ?, ?)");
            $insert->bind_param("ssss", $item, $desc, $catCode, $subCatCode);
            if ($insert->execute()) {
                $itemCode = $conn->insert_id;
                $msg = "✅ Item added. Code: <b>$itemCode</b>";
            } else {
                $msg = "❌ Error inserting: " . $conn->error;
            }
            $insert->close();
        }

        $conn->commit();
    } catch (Exception $e) {
        $conn->rollback();
        $msg = "❌ Transaction failed: " . $e->getMessage();
    }
}
?>

<div class="content-container">
    <div class="form-container">
        <div class="form-header">
            <h2>Item Entry</h2>
            <a href="/index.php" class="back-link">&larr; Back to Menu</a>
        </div>

        <?php if ($msg): ?>
            <div class="alert <?= str_starts_with($msg, '✅') ? 'alert-success' : 'alert-error' ?>">
                <?= $msg ?>
            </div>
        <?php endif; ?>

        <form id="itemForm" method="POST" autocomplete="off" class="item-form">
            <div class="form-group">
                <label for="category_code">Category*</label>
                <div class="select-wrapper">
                    <select name="category_code" id="category_code" required>
                        <option value="">Select Category</option>
                        <?php if ($categories && $categories instanceof mysqli_result): ?>
                            <?php while($row = $categories->fetch_assoc()): ?>
                                <option value="<?= $row['CategoryCode'] ?>"><?= htmlspecialchars($row['Category']) ?></option>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </select>
                    <a href="/modules/inventory/category.php" class="add-link">+ Add Category</a>
                </div>
            </div>

            <div class="form-group">
                <label for="sub_category_code">Sub-Category*</label>
                <div class="select-wrapper">
                    <select name="sub_category_code" id="sub_category_code" required>
                        <option value="">Select Sub-Category</option>
                    </select>
                    <a href="/modules/inventory/subcategory.php" class="add-link">+ Add Sub-Category</a>
                </div>
            </div>

            <div class="form-group">
                <label for="item_name">Item Name*</label>
                <div class="autocomplete-wrapper">
                    <input type="text" name="item_name" id="item_name" required placeholder="Enter item name">
                    <ul id="suggestions" class="autocomplete-list"></ul>
                </div>
            </div>

            <div class="form-group">
                <label for="description">Description</label>
                <textarea name="description" id="description" rows="4" placeholder="Enter item description"></textarea>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn-primary">Save Item</button>
            </div>
        </form>
    </div>
</div>

<script>
const subCategoryMap = <?= json_encode($subCategoryMap) ?>;
const catSelect = document.getElementById('category_code');
const subCatSelect = document.getElementById('sub_category_code');
const itemInput = document.getElementById('item_name');
const suggestionsList = document.getElementById('suggestions');

// Update sub-categories when category changes
catSelect.addEventListener('change', function() {
    const selectedCat = this.value;
    subCatSelect.innerHTML = '<option value="">Select Sub-Category</option>';
    if (subCategoryMap[selectedCat]) {
        subCategoryMap[selectedCat].forEach(sc => {
            const opt = document.createElement('option');
            opt.value = sc.SubCategoryCode;
            opt.textContent = sc.SubCategory;
            subCatSelect.appendChild(opt);
        });
    }
});

// Form validation
document.getElementById('itemForm').addEventListener('submit', function(e) {
    const cat = catSelect.value;
    const sub = subCatSelect.value;
    const item = itemInput.value.trim();
    if (!cat || !sub || item.length < 3) {
        alert('Please fill all required fields correctly.');
        e.preventDefault();
    }
});

// Item autocomplete
itemInput.addEventListener('input', async () => {
    const query = itemInput.value.trim();
    suggestionsList.innerHTML = '';

    if (query.length < 1) return;

    const res = await fetch(`/modules/inventory/search_item.php?q=${encodeURIComponent(query)}`);
    if (!res.ok) return;

    const items = await res.json();
    if (items.length > 0) {
        suggestionsList.style.display = 'block';
        items.forEach(data => {
            const li = document.createElement('li');
            li.textContent = data.Item;
            li.addEventListener('click', () => {
                itemInput.value = data.Item;
                document.getElementById('description').value = data.Description;
                catSelect.value = data.CategoryCode;
                catSelect.dispatchEvent(new Event('change'));
                setTimeout(() => {
                    subCatSelect.value = data.SubCategoryCode;
                }, 100);
                suggestionsList.style.display = 'none';
            });
            suggestionsList.appendChild(li);
        });
    } else {
        suggestionsList.style.display = 'none';
    }
});

// Close autocomplete when clicking outside
document.addEventListener('click', (e) => {
    if (!suggestionsList.contains(e.target) && e.target !== itemInput) {
        suggestionsList.style.display = 'none';
    }
});
</script>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?>