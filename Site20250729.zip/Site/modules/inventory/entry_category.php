<div class="page-title">Item Entry</div>
<form>
  <label>Item Name</label>
  <input type="text" placeholder="Enter item name">
  <button type="submit">Save</button>
</form>